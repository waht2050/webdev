package top.yogiczy.mytv

import java.io.File

/**
 * 应用全局变量
 */
object AppGlobal {
    /**
     * 缓存目录
     */
    lateinit var cacheDir: File
}